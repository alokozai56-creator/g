package axiom;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class AxiomClient implements ClientModInitializer {
    public static final StashFinder STASH = new StashFinder();
    private static KeyBinding toggleStash, clearLog;
    private static final KeyBinding.Category CATEGORY =
        KeyBinding.Category.create(Identifier.of("axiom", "main"));

    @Override
    public void onInitializeClient() {
        toggleStash = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.axiom.stash", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        clearLog = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.axiom.clear", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_CONTROL, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (toggleStash.wasPressed()) {
                STASH.enabled = !STASH.enabled;
                if (mc.player != null)
                    mc.player.sendMessage(Text.literal("[Axiom] StashFinder " + (STASH.enabled ? "ON" : "OFF")), true);
            }
            while (clearLog.wasPressed()) STASH.reset();
            STASH.tick(mc);
        });
    }
}
