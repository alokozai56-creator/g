package axiom;

import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.io.IOException;
import java.nio.file.*;
import java.util.HashSet;
import java.util.Set;

/** Scans loaded chunks for clusters of storage/spawner blocks and logs coords. */
public class StashFinder {
    public boolean enabled = true;
    public int threshold = 12;           // storage blocks per chunk to count as a "base"
    private final Set<Long> reported = new HashSet<>();

    public void reset() { reported.clear(); }

    public void tick(MinecraftClient mc) {
        if (!enabled || mc.world == null || mc.player == null || mc.player.age % 40 != 0) return;

        int r = mc.options.getViewDistance().getValue();
        ChunkPos origin = mc.player.getChunkPos();

        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(origin.x + dx, origin.z + dz);
                if (chunk == null) continue;
                long key = chunk.getPos().toLong();
                if (reported.contains(key)) continue;

                int storage = 0, spawners = 0;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity
                        || be instanceof ShulkerBoxBlockEntity || be instanceof HopperBlockEntity
                        || be instanceof DispenserBlockEntity || be instanceof FurnaceBlockEntity) storage++;
                    else if (be instanceof MobSpawnerBlockEntity) spawners++;
                }

                if (storage >= threshold || spawners > 0) {
                    reported.add(key);
                    int x = chunk.getPos().getStartX(), z = chunk.getPos().getStartZ();
                    String msg = String.format("[Axiom] Possible base @ %d, %d  (storage:%d spawners:%d)",
                        x, z, storage, spawners);
                    mc.player.sendMessage(Text.literal(msg), false);
                    log(msg);
                }
            }
        }
    }

    private void log(String line) {
        try {
            Path p = MinecraftClient.getInstance().runDirectory.toPath().resolve("axiom_bases.txt");
            Files.writeString(p, line + System.lineSeparator(),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {}
    }
}
