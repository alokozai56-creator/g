# Axiom Client (Fabric 1.21.11)
Build: `gradle build` (Java 21) -> jar in build/libs, drop in .minecraft/mods with Fabric + Fabric API.
Keys: Right Shift = toggle StashFinder, Right Ctrl = clear reported chunks.
Hits are printed in chat and saved to .minecraft/axiom_bases.txt.
Only detects chunks your client has loaded (render distance). Change versions in build.gradle as needed.
Use on singleplayer or anarchy servers that allow client mods; most servers ban this.

## Get the .jar with no setup
1. Make a free GitHub repo and upload this project's contents.
2. Open the Actions tab -> "build" -> latest run -> download the `axiom-jar` artifact.
3. Use the jar WITHOUT "-sources" in the name.
